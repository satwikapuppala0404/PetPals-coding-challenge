package com.challenge;

public class ItemDonation {
	private String itemType;

    public ItemDonation(String donorName, double amount, String itemType) {
        super();
        this.itemType = itemType;
    }

    // Getter and setter for itemType
    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    // Implementation of RecordDonation() to record an item donation
    public void recordDonation() {
        System.out.println("Item donation of type '" + itemType + "' recorded by " + getDonorName() + " of amount $" + getAmount());
    }

	private String getDonorName() {
		// TODO Auto-generated method stub
		return null;
	}
}


