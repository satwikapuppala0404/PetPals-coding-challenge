package com.challenge;

public class InvalidPetAgeException extends Exception{
	public InvalidPetAgeException(String message) {
        super(message);
    }

}
