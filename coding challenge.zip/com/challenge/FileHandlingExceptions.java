package com.challenge;
import java.io.FileNotFoundException;

public class FileHandlingExceptions extends Exception{
	 public FileHandlingExceptions(String message, FileNotFoundException cause) {
	        super(message, cause);
	    }
}